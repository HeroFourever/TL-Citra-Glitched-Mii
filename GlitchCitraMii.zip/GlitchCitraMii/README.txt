Hi!!!! So you want Citra's glitch mii on your island? Then let's get started!


[You will need a modded 3ds to do this]

-----------------------------------------------------------------------------------------------------------

1. Scan the included QR code into your Tomodachi Life island.

2. Extract your save data onto your SD card using Checkpoint or JKSM

3. Download the latest version of the Tomodachi Life Save editor: https://github.com/Brionjv/Tomodachi-Life-Save-Editor

4. Open the save editor, navigate to Mii Management\Mii and select é"'(-è_çà)

5. Hit "restore" and select the file in this folder called "Empty Mii Rebeccith.cfsd"

6. Hit save and restore your edited save back onto your 3ds using Checkpoint or JKSM


Now you're done!!!! Enjoy your glitched mii :D

-----------------------------------------------------------------------------------------------------------

Extra links:

Mod your 3ds: https://3ds.hacks.guide/

See how I made this: https://www.youtube.com/@HeroFourever

